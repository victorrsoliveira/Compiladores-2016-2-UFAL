from enum import Enum


class Categoria(Enum):
    # Identificador

    IDENTIFICADOR = {'tipo': 'IDENTIFICADOR', 'lexema': ''}

    # Constantes numericas

    CONSTANTE_INTEIRA = {'tipo': 'CONSTANTE NUMERICA', 'lexema': ''}
    CONSTANTE_PONTO_FLUTUANTE = {'tipo': 'CONSTANTE NUMERICA', 'lexema': ''}

    # Caractere

    CARACTERE_SIMPLES = {'tipo': 'CARACTERE', 'lexema': ''}

    # Cadeia de caracteres

    CADEIA_CARACTERES = {'tipo': 'CADEIA DE CARACTERES', 'lexema': ''}

    # Booleano

    # Ja definido nas palavras reservadas os possiveis valores para
    # o tipo de dado booleano

    # Palavras reservadas da linguagem

    TIPO_INTEIRO = {'tipo': 'PALAVRA RESERVADA', 'lexema': 'int'}
    TIPO_PONTO_FLUTUANTE = {'tipo': 'PALAVRA RESERVADA', 'lexema': 'float'}
    TIPO_CARACTERE = {'tipo': 'PALAVRA RESERVADA', 'lexema': 'char'}
    TIPO_BOOLEANO = {'tipo': 'PALAVRA RESERVADA', 'lexema': 'bool'}
    TIPO_CADEIA_CARACTERES = {'tipo': 'PALAVRA RESERVADA', 'lexema': 'string'}
    VALOR_VERDADEIRO = {'tipo': 'PALAVRA RESERVADA', 'lexema': 'TRUE'}
    VALOR_FALSO = {'tipo': 'PALAVRA RESERVADA', 'lexema': 'FALSE'}
    OPERADOR_NEGACAO = {'tipo': 'PALAVRA RESERVADA', 'lexema': 'not'}
    OPERADOR_CONJUNCAO = {'tipo': 'PALAVRA RESERVADA', 'lexema': 'and'}
    OPERADOR_DISJUNCAO = {'tipo': 'PALAVRA RESERVADA', 'lexema': 'or'}
    COMANDO_IF = {'tipo': 'PALAVRA RESERVADA', 'lexema': 'if'}
    COMANDO_ELSE = {'tipo': 'PALAVRA RESERVADA', 'lexema': 'else'}
    COMANDO_WHILE = {'tipo': 'PALAVRA RESERVADA', 'lexema': 'while'}
    COMANDO_DO = {'tipo': 'PALAVRA RESERVADA', 'lexema': 'do'}
    COMANDO_FOR = {'tipo': 'PALAVRA RESERVADA', 'lexema': 'for'}
    COMANDO_INPUT = {'tipo': 'PALAVRA RESERVADA', 'lexema': 'input'}
    COMANDO_PRINT = {'tipo': 'PALAVRA RESERVADA', 'lexema': 'print'}
    COMANDO_FUNCTION = {'tipo': 'PALAVRA RESERVADA', 'lexema': 'function'}
    TIPO_VOID = {'tipo': 'PALAVRA RESERVADA', 'lexema': 'void'}
    COMANDO_RETURN = {'tipo': 'PALAVRA RESERVADA', 'lexema': 'return'}
    COMANDO_MAIN = {'tipo': 'PALAVRA RESERVADA', 'lexema': 'main'}
    COMANDO_INT2STRING = {'tipo': 'PALAVRA RESERVADA', 'lexema': 'int2string'}
    COMANDO_FLOAT2STRING = {'tipo': 'PALAVRA RESERVADA', 'lexema': 'float2string'}

    # Operadores

    OPERADOR_SOMA = {'tipo': 'OPERADOR', 'lexema': '+'}
    OPERADOR_SUBTRACAO = {'tipo': 'OPERADOR', 'lexema': '-'}
    OPERADOR_MULTIPLICACAO = {'tipo': 'OPERADOR', 'lexema': '*'}
    OPERADOR_DIVISAO = {'tipo': 'OPERADOR', 'lexema': '/'}
    OPERADOR_RELACIONAL = {'tipo': 'OPERADOR', 'lexema': ''}  # vale para qualquer relacional

    # Atribuicao

    ATRIBUICAO = {'tipo': 'ATRIBUICAO', 'lexema': '='}

    # Delimitadores

    ABRE_PARENTESES = {'tipo': 'DELIMITADORES', 'lexema': '('}
    FECHA_PARENTESES = {'tipo': 'DELIMITADORES', 'lexema': ')'}
    ABRE_COLCHETES = {'tipo': 'DELIMITADORES', 'lexema': '['}
    FECHA_COLCHETES = {'tipo': 'DELIMITADORES', 'lexema': ']'}
    ABRE_CHAVES = {'tipo': 'DELIMITADORES', 'lexema': '{'}
    FECHA_CHAVES = {'tipo': 'DELIMITADORES', 'lexema': '}'}
    ASPAS_SIMPLES = {'tipo': 'DELIMITADORES', 'lexema': "'"}
    ASPAS_DUPLAS = {'tipo': 'DELIMITADORES', 'lexema': '"'}
    PONTO = {'tipo': 'DELIMITADORES', 'lexema': '.'}
    PONTO_VIRGULA = {'tipo': 'DELIMITADORES', 'lexema': ';'}
    VIRGULA = {'tipo': 'DELIMITADORES', 'lexema': ','}

file = open('programa4.txt','r')

nline, ncol = (0,0)

for line in file:
    nline += 1
    print('Line {}: {}'.format(nline, line), end='')
    print('Elements:')
    tk = ''
    for c in line:
        ncol += 1
        if not c.isalnum():
            if tk != '':
                print(tk)
                tk = ''
            # Delimitadores
            if c in ['(', ')', '[', ']', '{', '}', "'", '"', '.', ';', ',']:
                print(c)
                continue
            # Operadores e atribuicao
            if c in ['+', '-', '*', '/', '=']:
                print(c)
                continue
        elif c.isalnum():
            tk = tk + c
            continue